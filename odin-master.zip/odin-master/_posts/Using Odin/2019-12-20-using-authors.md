---
layout: post
title: "How to Use Authors"
date: 2019-11-05 08:44:38 -0400
category: using-odin
author: mac
short-description: Give credit to those who write your support articles
---

**This article is coming soon**



---
layout: post
title: "Creating a New Article"
date: 2019-11-05 08:44:38 -0400
category: using-odin
author: mac
short-description: How to add a new article to your Odin knowledge base
---

**This article is coming soon**



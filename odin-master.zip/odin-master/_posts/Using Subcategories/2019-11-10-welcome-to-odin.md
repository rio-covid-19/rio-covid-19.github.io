---
layout: post
title: "Subcategory Post"
date: 2019-11-05 08:44:38 -0400
category: subcategory-one
subcategory: 
author: mac
short-description: A quick overview of Odin to get you started
---

-----

Odin is the Norse god of knowledge. He'll help deliver knowledge to your customers with his ravens.

Odin was built out of a frustration with various knowledge base and support software solutions and a desire to build something for the sake of building something.

**More info coming soon**



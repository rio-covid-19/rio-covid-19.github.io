# Odin Knowledge Base

Odin is a Jekyll template for knowledgebases and support sites. Please see the [official Jekyll docs](https://jekyllrb.com/docs/) for more info on running, building and editing a Jekyll site.

*Full documentation is in the works and coming soon*





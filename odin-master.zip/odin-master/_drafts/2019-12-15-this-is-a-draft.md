---
layout: post
title: "This is a Draft Article"
date: 2019-12-14 08:44:38 -0400
category: partner-club
category-name: "Partner Club"
author: mac
short-description: This is a short description, less than 60 characters if possible.
---

Insert your article here, using markdown formatting.

